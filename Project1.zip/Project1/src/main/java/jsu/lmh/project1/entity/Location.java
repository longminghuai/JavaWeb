package jsu.lmh.project1.entity;

import lombok.Data;

@Data
public class Location {
    private String province;
    public String city;
}
