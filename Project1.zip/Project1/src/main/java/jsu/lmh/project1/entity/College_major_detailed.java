package jsu.lmh.project1.entity;

import lombok.Data;

@Data

public class College_major_detailed {
  College college;
  User user;
  Major major;
}
